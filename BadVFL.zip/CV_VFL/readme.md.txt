
Datasets:
The datasets in computer vision domain used in out paper are CIFAR-10, ImageNet, Breast Histopathology Images, which can be found on the corresponding official website. 

Poison Process:
python train_backdoor.py 

Defense Process:
python defense_normal.py (for noisy gradients)
python defense_grad_spar.py (for gradients compression)

